package com.example.BillingSystem.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Request {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private LocalDateTime time;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "nurse_latitude")),
            @AttributeOverride(name = "longitude", column = @Column(name = "nurse_longitude"))
    })
    private Point nursePoint;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(name = "latitude", column = @Column(name = "client_latitude")),
            @AttributeOverride(name = "longitude", column = @Column(name = "client_longitude"))
    })
    private Point clientPoint;

    private double rating;

    @ManyToOne
    @JoinColumn(name = "service_type_id", nullable = false)
    private ServiceType serviceType;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getTime() {
        return time;
    }

    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    public Point getNursePoint() {
        return nursePoint;
    }

    public void setNursePoint(Point nursePoint) {
        this.nursePoint = nursePoint;
    }

    public Point getClientPoint() {
        return clientPoint;
    }

    public void setClientPoint(Point clientPoint) {
        this.clientPoint = clientPoint;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public ServiceType getServiceType() {
        return serviceType;
    }

    public void setServiceType(ServiceType serviceType) {
        this.serviceType = serviceType;
    }

    public void setPrice(double finalPrice) {
    }

    public Object getClientPhoneNumber() {
        return null;
    }

    public Object getNursePhoneNumber() {
        return null;
    }

    public void setClientPhoneNumber(Object clientPhoneNumber) {
    }

    public void setNursePhoneNumber(Object nursePhoneNumber) {
    }
}
