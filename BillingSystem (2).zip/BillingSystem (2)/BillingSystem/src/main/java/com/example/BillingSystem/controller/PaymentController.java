package com.example.BillingSystem.controller;

import com.example.BillingSystem.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @PostMapping("/initiate")
    public String initiatePayment(
            @RequestParam String clientPhoneNumber,
            @RequestParam String nursePhoneNumber,
            @RequestParam String amount) {
        return paymentService.initiatePayment(clientPhoneNumber, nursePhoneNumber, amount);
    }

    @GetMapping("/status/{transactionId}")
    public String checkTransactionStatus(@PathVariable String transactionId) {
        return paymentService.checkTransactionStatus(transactionId);
    }
}
