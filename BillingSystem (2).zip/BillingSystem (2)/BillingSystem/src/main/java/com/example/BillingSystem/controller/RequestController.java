package com.example.BillingSystem.controller;

import com.example.BillingSystem.model.Request; // Import your Request model
import com.example.BillingSystem.service.RequestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/requests")
public class RequestController {

    private final RequestService requestService;

    @Autowired
    public RequestController(RequestService requestService) {
        this.requestService = requestService;
    }

    // Get all requests
    @GetMapping
    public List<Request> getAllRequests() {
        return requestService.findAll();
    }

    // Create a new request
    @PostMapping
    public Request createRequest(@RequestBody Request request) {
        return requestService.createRequest(request); // Call the createRequest method
    }

    // Get a request by ID
    @GetMapping("/{id}")
    public Request getRequestById(@PathVariable Long id) {
        return requestService.findById(id); // Implement findById in RequestService
    }

    // Update a request
    @PutMapping("/{id}")
    public Request updateRequest(@PathVariable Long id, @RequestBody Request updatedRequest) {
        return requestService.updateRequest(id, updatedRequest); // Implement updateRequest in RequestService
    }

    // Delete a request
    @DeleteMapping("/{id}")
    public void deleteRequest(@PathVariable Long id) {
        requestService.deleteRequest(id); // Implement deleteRequest in RequestService
    }
}
