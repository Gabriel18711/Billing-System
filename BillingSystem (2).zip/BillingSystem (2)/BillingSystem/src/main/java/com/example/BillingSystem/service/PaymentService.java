// PaymentService.java
package com.example.BillingSystem.service;

import kong.unirest.HttpResponse;
import kong.unirest.Unirest;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    public String initiatePayment(String clientPhoneNumber, String nursePhoneNumber, String amount) {
        HttpResponse<String> response = Unirest.post("https://api.moneyunify.com/v2/request_payment")
                .header("User-Agent", "Apidog/1.0.0 (https://apidog.com)")
                .field("muid", "01JB9D8CPZEC8JWEPBDP510HGH")
                .field("phone_number", clientPhoneNumber)
                .field("amount", amount)
                .asString();

        return response.getBody();
    }

    public String checkTransactionStatus(String transactionId) {
        // Implement transaction status check with Unirest as needed
        return "Status of transaction: " + transactionId;
    }
}
